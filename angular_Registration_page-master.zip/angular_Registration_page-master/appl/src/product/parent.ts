import {Component} from'@angular/core';

@Component({
    selector:'parent',
    template:`
            <two></two>`    
})
export class ParentComponent{



}